PHP Program developed and compiled via wamp server.

Import the mysql database (talentplus.sql) with the database name talentplus

Username and Password stored in the database is;

Username         Password
talentplus       1234
shola            1234