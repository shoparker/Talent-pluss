<?php
date_default_timezone_set ("Africa/Lagos");

$server = "localhost";
$username = "root";
$password = "";
$database = "talentplus";
$link = mysqli_connect($server,$username,$password,$database);
$con = mysql_connect($server,$username,$password,$database) or die(include "notfound.php");
mysql_select_db($database) or DIE(include "notfound.php");

?>
