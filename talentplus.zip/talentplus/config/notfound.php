<?php
header("location: ../temporarily_unavailable.php");
?>
