<?php
if($phx=="1")
{
?>
<table width="766" height="37" border="0" align="center">
  <tr>
    <td bgcolor="#FFFFCC"><center><strong><?php echo "$mess"; ?></strong></center></td>
  </tr>
</table><br />
<?php
}
?>
<div align="center">
  <form id="form1" name="form1" method="post" action="result.php">
    <table width="501" height="261" border="0">
      <tr>
        <td height="121" colspan="2"><img src="images/banner.jpg" width="494" height="150" /></td>
      </tr>
      <tr>
        <td width="252" rowspan="3"><img src="images/logo.jpg" width="255" height="150" /></td>
        <td width="233" height="47" bgcolor="#FFFFCC"><strong>USERNAME:</strong><br />
          <label>
            <input name="userx" type="text" id="userx" />
        </label></td>
      </tr>
      <tr>
        <td height="42"><strong>PASSWORD:</strong><br />
            <input name="passx" type="password" id="passx"/></td>
      </tr>
      <tr>
        <td height="36" bgcolor="#FFFFCC"><input type="submit" name="Submit" value="Submit" /></td>
      </tr>
    </table>
  </form>
</div>
