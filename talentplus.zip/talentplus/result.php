<?php 
require('config/dbconnection.php');

$userx=$_POST["userx"];
$passx=$_POST["passx"];

$getuserinfoghq0="SELECT * from users where userx='$userx' and passx='$passx'";
$getuserinfo2ghq0=mysql_query($getuserinfoghq0) or die(include "notfound.php");
$resultaccessghq0=mysql_query($getuserinfoghq0);
$num_result=mysql_num_rows($resultaccessghq0);
$getuserinfo3ghq0=mysql_fetch_array($getuserinfo2ghq0);
$namex=$getuserinfo3ghq0[namex];


if($userx=="" || $passx=="")
{
$phx="1";
$mess="Unable to log-in!!! No Log-in detail (Username or Password).";
include "index.php";
exit;
}

if($num_result==0)
{
$phx="1";
$mess="Unable to log-in!!! Invalid Log-in details.";
include "index.php";
exit;
}
?>
<style type="text/css">
<!--
.style2 {
	font-size: 36px;
	font-weight: bold;
}
-->
</style>


<div align="center">
  <form id="form1" name="form1" method="post" action="index.php">
    <span class="style2">    WELCOME <?php echo "$namex"; ?></span><br />
    <label>
    <br />
    <input name="logout" type="submit" id="LOG-OUT" value="LOG-OUT"/>
    </label>
  </form>
</div>
