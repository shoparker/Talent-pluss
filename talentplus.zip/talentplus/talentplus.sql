-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 16, 2022 at 12:44 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `talentplus`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `sn` int(200) NOT NULL auto_increment,
  `userx` varchar(1000) NOT NULL,
  `passx` varchar(1000) NOT NULL,
  `namex` varchar(1000) NOT NULL,
  PRIMARY KEY  (`sn`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`sn`, `userx`, `passx`, `namex`) VALUES 
(1, 'talentplus', '1234', 'TALENT PLUS'),
(2, 'shola', '1234', 'SHOLA');
